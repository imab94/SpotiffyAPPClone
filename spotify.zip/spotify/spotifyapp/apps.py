from django.apps import AppConfig


class SpotifyappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "spotifyapp"
