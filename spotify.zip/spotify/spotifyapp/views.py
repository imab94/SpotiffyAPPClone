from django.shortcuts import render

# Create your views here.


def home(request):
    return render(request,'index.html')

def login_page(request):
    return render(request,'login.html')

def register_page(request):
    return render(request,'signup.html')

def phone_number_login(request):
    return render(request,'phone_number_login.html')


def verifications(request):
    return render(request,'verification.html')

def forget_password_page(request):
    return render(request,'forget_password.html')